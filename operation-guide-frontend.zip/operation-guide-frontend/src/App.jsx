import React from "react";
import AppRouter from "./router/AppRouter";

const App = () => <AppRouter />;

export default App;