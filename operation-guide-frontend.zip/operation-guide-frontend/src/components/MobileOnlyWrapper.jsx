import React from "react";
import NotSupported from "../pages/NotSupported";

const isMobile = () => {
  const userAgent = navigator.userAgent || navigator.vendor || window.opera;
  return /android|ipad|iphone|ipod/i.test(userAgent.toLowerCase());
};

const MobileOnlyWrapper = ({ children }) => {
  return isMobile() ? children : <NotSupported />;
};

export default MobileOnlyWrapper;