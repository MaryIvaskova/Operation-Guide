import React from "react";

const Home = () => {
  return (
    <div style={{ padding: "2rem", textAlign: "center" }}>
      <h2>Домашня сторінка</h2>
      <p>Тут буде головний контент додатку.</p>
    </div>
  );
};

export default Home;