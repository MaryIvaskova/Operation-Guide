import React from "react";

const NotSupported = () => {
  return (
    <div style={{
      display: "flex", justifyContent: "center", alignItems: "center", height: "100vh", padding: "2rem", textAlign: "center"
    }}>
      <div>
        <h1>Цей сайт доступний лише для мобільних пристроїв 📱</h1>
        <p>Будь ласка, відкрийте сайт на телефоні або планшеті.</p>
      </div>
    </div>
  );
};

export default NotSupported;