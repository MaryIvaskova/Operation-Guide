import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/splash.css";
const Splash = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate("/home");
    }, 3000); // 3 секунди

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="splash-container">
      <h1 className="splash-text">Operation Guide</h1>
    </div>
  );
};

export default Splash;