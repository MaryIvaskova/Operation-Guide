import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import MobileOnlyWrapper from "../components/MobileOnlyWrapper";
import Splash from "../styles/Splash";
import Home from "../pages/Home";
import NotSupported from "../pages/NotSupported";

const AppRouter = () => {
  return (
    <BrowserRouter>
      <MobileOnlyWrapper>
        <Routes>
          <Route path="/" element={<Splash />} />
          <Route path="/home" element={<Home />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </MobileOnlyWrapper>
    </BrowserRouter>
  );
};

export default AppRouter;